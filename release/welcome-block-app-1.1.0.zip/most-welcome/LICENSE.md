This project is licensed under the GNU General Public License v2.0 or later.

See <https://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
